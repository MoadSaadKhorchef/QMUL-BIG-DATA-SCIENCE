# cc_mini_project
